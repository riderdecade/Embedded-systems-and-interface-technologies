姓名：甘甜   学号：520030910058

UART配置：波特率115200，数据位8位，无校验位，停止位1位，收发数据类型ASCII

UART指令：

1. HELP：返回帮助菜单


2.INIT TIME：初始化时间为00：00：00 ，格式：INIT TIME
返回：TIME00：00：00


3. SET TIME：设置时间，格式：SET Txx:xx:xx  or SET Txx-xx-xx，其中第一项为小时，第二项为分钟，第三项为秒
返回：设置的时间，格式：TIMExx:xx:xx，同时模式切换至时间显示（模式3）


4. SET DATE：设置日期，格式：SET Dxx:xx:xx  or SET Dxx-xx-xx，其中第一项为年，第二项为月，第三项为日
返回：设置的日期，格式：DATExx-xx-xx，同时模式切换至日期显示（模式1）


5. SET ALARM：设置闹钟，格式：SET Axx:xx:xx  or SET Axx-xx-xx，其中第一项为小时，第二项为分钟，第三项为秒
返回：设置的闹钟时间，格式：ALARMxx:xx:xx，同时模式切换至闹钟显示（模式5）


6. GET TIME：获取时间，格式：GET TIME
返回：当前时间，格式：TIMExx:xx:xx，其中第一项为小时，第二项为分钟，第三项为秒


7. GET DATE：获取日期，格式：GET DATE
返回：当前日期，格式：DATExx-xx-xx，其中第一项为年，第二项为月，第三项为日


8. GET TIME：获取闹钟时间，格式：GET ALARM
返回：当前闹钟时间，格式：ALARMxx:xx:xx，其中第一项为小时，第二项为分钟，第三项为秒



注：

1. 所有指令均不区分大小写，但无空格容错

2.当指令正确但数字格式错误时会返回“error！”