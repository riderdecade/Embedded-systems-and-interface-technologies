#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <ctype.h>
#include "hw_memmap.h"
#include "debug.h"
#include "gpio.h"
#include "hw_i2c.h"
#include "hw_types.h"
#include "i2c.h"
#include "pin_map.h"
#include "sysctl.h"
#include "systick.h"
#include "interrupt.h"
#include "uart.h"
#include "hw_ints.h"
#include "string.h"
#include "pwm.h"
//#include "strcmp.h"

#define SYSTICK_FREQUENCY		1000			//1000hz

#define	I2C_FLASHTIME				1000				//1000mS
#define GPIO_FLASHTIME			300				//300mS
//*****************************************************************************
//
//I2C GPIO chip address and resigster define
//
//*****************************************************************************
#define TCA6424_I2CADDR 					0x22
#define PCA9557_I2CADDR						0x18

#define PCA9557_INPUT							0x00
#define	PCA9557_OUTPUT						0x01
#define PCA9557_POLINVERT					0x02
#define PCA9557_CONFIG						0x03

#define TCA6424_CONFIG_PORT0			0x0c
#define TCA6424_CONFIG_PORT1			0x0d
#define TCA6424_CONFIG_PORT2			0x0e

#define TCA6424_INPUT_PORT0				0x00
#define TCA6424_INPUT_PORT1				0x01
#define TCA6424_INPUT_PORT2				0x02

#define TCA6424_OUTPUT_PORT0			0x04
#define TCA6424_OUTPUT_PORT1			0x05
#define TCA6424_OUTPUT_PORT2			0x06




void 		Delay(uint32_t value);
void 		S800_GPIO_Init(void);
uint8_t 	I2C0_WriteByte(uint8_t DevAddr, uint8_t RegAddr, uint8_t WriteData);
uint8_t 	I2C0_ReadByte(uint8_t DevAddr, uint8_t RegAddr);
void		S800_I2C0_Init(void);
void 		S800_UART_Init(void);
void showstudent(void);//显示学号
void writeseg(int n, int *show, bool flag);//写入数码管
void adjust(void);//进位调整
void getkey(void);//获取按键
void Showtime(void);//显示时间
void settime(void);//设置时间
void showdate(void);//显示日期
void setdate(void);//设置日期
bool push(int n);//获取按键
void showclock(void);//显示闹钟
void clock(void);//设置闹钟
void ring(void);//闹钟响铃
void ring2(void);//倒计时响铃
void showtimer(void);//显示倒计时
void timer(void);//倒计时设置
void PWM_Init(void);
void print(void);
void UARTStringPut(uint8_t *cMessage);

volatile uint16_t systick_1000ms_couter=1000, systick_5s_counter=5000, systick_500ms_couter=500, systick_250ms_couter=250,systick_10ms_couter=10,systick_1ms_couter=1;
volatile uint8_t  systick_1000ms_status=0, systick_5s_status=0, systick_500ms_status=0, systick_250ms_status=0,systick_10ms_status=0,systick_1ms_status=0;

volatile uint8_t result,cnt,key_value,gpio_status;
volatile uint8_t rightshift = 0x01;
uint32_t ui32SysClock;
uint8_t seg7[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x58,0x5e,0x079,0x71,0x40};
uint8_t led[] = {0xfe,0xfd,0xfb,0xf7,0xef,0xdf,0xbf,0x7f};
int student_num[8] = {2,1,9,1,0,3,7,3};
uint8_t uart_receive_char;
int hour=8 ,minute=0,second=59,year=2023,month=6,day=11,clock_hour=8 ,clock_minute=01,clock_second=20,timer_s=1,timer_ms=40;//初始化
int mms=0,s=0,s1=0,mms1=0,s2=0,mms2=0;
int i = 0,j=0,k=0,m=0,n=0;
bool clock_able=false,ring_able=false,timer_able=false,press1=false,press2=false;//使能信号
uint8_t initialButtonState;
uint8_t currentButtonState;

char look[256];
char RxBuf[256];
int counter=1,leapyear,daysInMonth;
long int student=37301912;

void UARTStringGetNonBlocking(void);
void UARTStringPutNonBlocking(const char *cMessage);

int main(void)
{
	volatile uint16_t	i2c_flash_cnt,gpio_flash_cnt;
	ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_16MHZ |SYSCTL_OSC_INT | SYSCTL_USE_PLL |SYSCTL_CFG_VCO_480), 20000000);

	SysTickPeriodSet(ui32SysClock/SYSTICK_FREQUENCY);
	SysTickEnable();
	SysTickIntEnable();//Enable Systick interrupt


	S800_GPIO_Init();
	S800_I2C0_Init();
	S800_UART_Init();
	PWM_Init();

	IntEnable(INT_UART0);
  UARTIntEnable(UART0_BASE, UART_INT_RX | UART_INT_RT);	//Enable UART0 RX,TX interrupt
  IntMasterEnable();

  showstudent();//显示学号
	while (1)
	{  adjust();//调整进位
	   getkey();//获取按键1
	   if(counter==1) {Showtime();Delay(100);}//状态机
	   else if(counter==2) settime();
	   else if(counter==3) {showdate();Delay(100);}
	   else if(counter==4) setdate();
	   else if(counter==5) clock();
	   else if(counter==6) timer();

       while(push(8)) clock_able=!clock_able;//闹钟使能
       while(push(6)) timer_able=!timer_able;//倒计时使能
       if(hour==clock_hour&&minute==clock_minute&&second==clock_second&&clock_able) ring();//闹钟响的条件判断

       if(GPIOPinRead(GPIO_PORTJ_BASE,GPIO_PIN_0)==0&&!press1)//红按键1的检测
       { press1=true;
				 sprintf(look, "%s%d.%02d", "1_PRESS", s, mms);
        UARTStringPutNonBlocking(look);
				 s1=s;mms1=mms;
  }
	     else if(GPIOPinRead(GPIO_PORTJ_BASE,GPIO_PIN_0)&&press1)
			 {press1=false;
				 sprintf(look, "%s%d.%02d", "  1_UNPRESS", s, mms);
        UARTStringPutNonBlocking(look);
			 print();}

        if(GPIOPinRead(GPIO_PORTJ_BASE,GPIO_PIN_1)==0&&!press2)//红按键2的检测
       { press2=true;
				 sprintf(look, "%s%d.%02d", "2_PRESS", s, mms);
        UARTStringPutNonBlocking(look);
				 s1=s;mms1=mms;
  }
	     else if(GPIOPinRead(GPIO_PORTJ_BASE,GPIO_PIN_1)&&press2)
			 {press2=false;
				 sprintf(look, "%s%d.%02d", "  2_UNPRESS", s, mms);
        UARTStringPutNonBlocking(look);
			 print();}

}
	}
void print(void)//计算并显示按下按键的间隔时间
{
   if(mms>=mms1) {mms2=mms-mms1;s2=s-s1;}
	 else {mms2=mms+1000-mms1;s2=s-1-s1;}
	 sprintf(look, "%s%d.%02d", "  PERIOD", s2, mms2);
        UARTStringPutNonBlocking(look);
}

void showstudent(void)
{
systick_250ms_status = 0; systick_250ms_couter=250;
	for(m=0;m<3;++m)
	{for(k=1;k<9;++k){
	while(1)
	{
		for(i = 0; i < k; i++)
			writeseg(i, student_num, 1); //数码管显示
		if (systick_250ms_status)
		{
			I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0); //使得显示清晰
			systick_250ms_status = 0;
			break;
		}
		}
}
}

hour=8 ,minute=0,second=59,year=2023,month=6,day=11,clock_hour=8 ,clock_minute=01,clock_second=20,timer_s=1,timer_ms=40;
 mms=0,s=0,s1=0,mms1=0,s2=0,mms2=0,clock_able=false,ring_able=false,timer_able=false,press1=false,press2=false;//恢复初始值
}

void writeseg(int n, int *show, bool flag)
{
	I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0); //使得显示清晰
	if (flag) I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT1,seg7[show[n]]);
	if (flag) I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,1<<n);
	I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,~1<<n);
	SysCtlDelay(ui32SysClock/3000);
	I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0);
}

void adjust(void)
{
    if(second==60) {minute++;second=0;}
    if(minute==60) {hour++;minute=0;}
    if(hour==24) {hour=0;day++;}

    if(clock_second==60) {clock_minute++;clock_second=0;}
    if(clock_minute==60) {clock_hour++;clock_minute=0;}
    if(clock_hour==24) {clock_hour=0;}

    if (year % 4 == 0) {
        if (year % 100 == 0) {
            if (year % 400 == 0) {leapyear=1;}
            else {leapyear=0;}
        } else {leapyear=1;}
    } else {leapyear=0;}//判断是否为闰年

    switch (month) {//计算月份的天数
        case 2:
            if (leapyear) {daysInMonth = 29;}
            else {daysInMonth = 28;}
            break;
        case 4:case 6:case 9:case 11:daysInMonth = 30;
            break;
        default:
            daysInMonth = 31;
            break;
    }

    if (day > daysInMonth) {day = 1;month++;}
    if (month > 12) {month = 1; year++;}

    if(timer_ms == 00 && timer_s!= 00){timer_s--;timer_ms = 99;}
    if(timer_ms == 00 && timer_s == 00){timer_able = false;ring2();}

    if(mms==1000){s++;mms=0;}



}

void getkey(void)
{
    if(push(1)) 
		{counter=counter+1;if(counter>6) counter=1;
			if(counter==1) UARTStringPut((uint8_t *)"\r\nshowtime\r\n");
	   else if(counter==2) UARTStringPut((uint8_t *)"\r\nsettime\r\n");
	   else if(counter==3) UARTStringPut((uint8_t *)"\r\nshowdate\r\n");
	   else if(counter==4) UARTStringPut((uint8_t *)"\r\nsetdate\r\n");
	   else if(counter==5) UARTStringPut((uint8_t *)"\r\nclock\r\n");
	   else if(counter==6) UARTStringPut((uint8_t *)"\r\ntimer\r\n");
		}
	  
	   

}
void Showtime(void)
{   result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[counter-1]);//显示时间模式，led1亮起
	if(clock_able) result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[5]);//判断闹钟使能则led6亮起
	if(rightshift == 0x01)   i = hour/10;
	if(rightshift == 0x02)   i = hour%10;
	if(rightshift == 0x08)   i = minute/10;
	if(rightshift == 0x10)   i = minute%10;
	if(rightshift == 0x40)   i = second/10;
	if(rightshift == 0x80)   i = second%10;
	if(rightshift == 0x04 || rightshift==0x20)   i = 16;

	  result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT1,seg7[i]);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,rightshift);
	if(rightshift!=0x80)
	    rightshift*=2;
  else
			rightshift= 0x01;
}

void settime(void)
{
	  Showtime();
    result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[counter-1]);//设置时间模式，led2亮起
	if(clock_able) result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[5]);//判断闹钟使能则led6亮起
    while(push(2) ) {second++;Showtime();Delay(100);}

    while(push(3) ) {minute++;Showtime();Delay(100);}

    while(push(4) ) {hour++;Showtime();Delay(100);}

}
bool push(int n)
{
	if(I2C0_ReadByte(TCA6424_I2CADDR, TCA6424_INPUT_PORT0) == 0xff)
			return false;

		if(I2C0_ReadByte(TCA6424_I2CADDR, TCA6424_INPUT_PORT0) == led[n-1])				//判断是否按下
		{
			result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0);
			Delay(1000000);       //延迟消抖
			while(I2C0_ReadByte(TCA6424_I2CADDR, TCA6424_INPUT_PORT0) == led[n-1])
			//GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_0,GPIO_PIN_0);			//按下时灯亮
			Delay(1000);
			//GPIOPinWrite(GPIO_PORTF_BASE,GPIO_PIN_0,0x0);

			return true;
		}
		return false;
}
/*bool push(int n)
{
    // Read initial button state
    initialButtonState = I2C0_ReadByte(TCA6424_I2CADDR, TCA6424_INPUT_PORT0);

    // Check if all button pins are high (no button press)
    if (initialButtonState == 0xFF) {
        return false;
    }

    // Wait for a brief period (debounce delay)
    Delay(100);

    // Read button state again
    currentButtonState = I2C0_ReadByte(TCA6424_I2CADDR, TCA6424_INPUT_PORT0);

    // Check if the button state is stable and matches the initial state
    if (currentButtonState == initialButtonState && currentButtonState == led[n-1]) {
        // Perform the desired actions
        result = I2C0_WriteByte(TCA6424_I2CADDR, TCA6424_OUTPUT_PORT2, 0);
        Delay(1000000);

        // Wait until the button is released
        while (I2C0_ReadByte(TCA6424_I2CADDR, TCA6424_INPUT_PORT0) == led[n-1]) {
            // Optional: Add a small delay or other operations if needed
        }

        return true;
    }

    return false;
}*/

void showdate(void)
{
    result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[counter-1]);//显示日期模式，led3亮起
	if(clock_able) result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[5]);//判断闹钟使能则led6亮起
	if(rightshift == 0x01)   i = year/1000;
	if(rightshift == 0x02)   i = (year/100)%10;
	if(rightshift == 0x04)   i = (year/10)%10;
	if(rightshift == 0x08)   i = year%10;
	if(rightshift == 0x10)   i = month/10;
	if(rightshift == 0x20)   i = month%10;
	if(rightshift == 0x40)   i = day/10;
	if(rightshift == 0x80)   i = day%10;

	  result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT1,seg7[i]);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,rightshift);
	if(rightshift!=0x80)
	    rightshift*=2;
  else
			rightshift= 0x01;
}

void setdate(void)
{
	  showdate();
    result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[counter-1]);//设置日期模式，led4亮起
	if(clock_able) result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[5]);//判断闹钟使能则led6亮起
    while(push(2) ) {day++;showdate();Delay(100);}

    while(push(3) ) {month++;showdate();Delay(100);}

    while(push(4) ) {year++;showdate();Delay(100);}

}

void showclock(void)
{
    result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[counter-1]);//闹钟设置模式，led5亮起
	if(clock_able) result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[5]);//判断闹钟使能则led6亮起
	if(rightshift == 0x01)   i = clock_hour/10;
	if(rightshift == 0x02)   i = clock_hour%10;
	if(rightshift == 0x08)   i = clock_minute/10;
	if(rightshift == 0x10)   i = clock_minute%10;
	if(rightshift == 0x40)   i = clock_second/10;
	if(rightshift == 0x80)   i = clock_second%10;
	if(rightshift == 0x04 || rightshift==0x20)   i = 16;

	  result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT1,seg7[i]);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,rightshift);
	if(rightshift!=0x80)
	    rightshift*=2;
  else
			rightshift= 0x01;
}
void clock(void)
{
    showclock();
    while(push(2) ) {clock_second++;showclock();Delay(100);}

    while(push(3) ) {clock_minute++;showclock();Delay(100);}

    while(push(4) ) {clock_hour++;showclock();Delay(100);}

}

void ring(void)
{
    while(!push(7)){
	Showtime();
	PWMGenPeriodSet(PWM0_BASE, PWM_GEN_3, 100000);

	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_7,500);
  while(push(7)) return;//若按键7按下则停止闹铃
	PWMOutputState(PWM0_BASE,PWM_OUT_7_BIT,true);
	Delay(10000);
	PWMOutputState(PWM0_BASE,PWM_OUT_7_BIT,false);
      }

return;
}

void ring2(void)
{
    while(!push(5)){
	PWMGenPeriodSet(PWM0_BASE, PWM_GEN_3, 120000);
    showtimer();
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_7,600);
  while(push(5)) break;//若按键5按下则停止闹铃
	PWMOutputState(PWM0_BASE,PWM_OUT_7_BIT,true);
	Delay(10000);
	PWMOutputState(PWM0_BASE,PWM_OUT_7_BIT,false);
      }
   timer_s=5;
			return;

}

void timer(void)
{
    showtimer();
    while(push(2) )
        {
            timer_s++;
            if(timer_s>99) timer_s=99;
            showtimer();Delay(100);

        }

    while(push(3) )
        {
            timer_ms++;
            if(timer_ms==100) {timer_ms=0;timer_s++;}
            showtimer();Delay(100);
        }


}

void showtimer(void)
{
    result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[counter]);//倒计时模式，led7亮起
	if(clock_able) result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,led[5]);//判断闹钟使能则led6亮起
    if(rightshift == 0x10)
	{
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT1,seg7[timer_s/10]);	//write port 1
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,rightshift);	//write port 2
	}
	if(rightshift == 0x20)
	{
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT1,seg7[timer_s%10]|0x80);	//write port 1
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,rightshift);	//write port 2
	}
	if(rightshift == 0x40)
	{
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT1,seg7[timer_ms/10]);	//write port 1
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,rightshift);	//write port 2
	}
	if(rightshift == 0x80)
	{
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT1,seg7[timer_ms%10]);	//write port 1
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,rightshift);	//write port 2
	}
	if(rightshift == 0x01|rightshift == 0x02|rightshift == 0x04|rightshift == 0x08)
	{
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,0);
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT1,seg7[16]);	//write port 1
		result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_OUTPUT_PORT2,rightshift);	//write port 2
	}

	if(rightshift != 0x80)
	    rightshift = rightshift<<1;
  else
			rightshift= 0x01;
}

void Delay(uint32_t value)
{
	uint32_t ui32Loop;
	for(ui32Loop = 0; ui32Loop < value; ui32Loop++){};
}


void UARTStringPut(uint8_t *cMessage)
{
	while(*cMessage!='\0')
		UARTCharPut(UART0_BASE,*(cMessage++));
}


void UARTStringPutNonBlocking(const char *cMessage)
{
	while(*cMessage!='\0')
	{
		if (UARTSpaceAvail(UART0_BASE))
		  UARTCharPutNonBlocking(UART0_BASE,*(cMessage++));
	}
}

void UARTStringGetNonBlocking(void)
{
	 uint8_t cnt = 0;
   while( UARTCharsAvail(UART0_BASE) )
	 {
     RxBuf[cnt++] = UARTCharGetNonBlocking(UART0_BASE);
   }
   RxBuf[cnt]='\0';
}

void PWM_Init(void)
{
  SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOK);

  GPIOPinConfigure(GPIO_PK5_M0PWM7);

	GPIOPinTypePWM(GPIO_PORTK_BASE, GPIO_PIN_5);
  PWMGenConfigure(PWM0_BASE, PWM_GEN_3, PWM_GEN_MODE_UP_DOWN |PWM_GEN_MODE_NO_SYNC);
  PWMGenPeriodSet(PWM0_BASE, PWM_GEN_3, 20000);

    PWMClockSet(PWM0_BASE, PWM_SYSCLK_DIV_1);
	PWMPulseWidthSet(PWM0_BASE, PWM_OUT_7,10000);
	PWMOutputState(PWM0_BASE, PWM_OUT_7_BIT, false);
	PWMGenEnable(PWM0_BASE, PWM_GEN_3);
}
void S800_UART_Init(void)
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);						//Enable PortA
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA));			//Wait for the GPIO moduleA ready

	GPIOPinConfigure(GPIO_PA0_U0RX);												// Set GPIO A0 and A1 as UART pins.
  GPIOPinConfigure(GPIO_PA1_U0TX);

  GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

	// Configure the UART for 115,200, 8-N-1 operation.
  UARTConfigSetExpClk(UART0_BASE, ui32SysClock,115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |UART_CONFIG_PAR_NONE));
	UARTStringPut((uint8_t *)"                                                                \r                                                                \r                                                                \r                     @@@@@@                             @        \r                       @                                @        \r                       @                                @        \r                       @                                @        \r                     @@@@@@                             @        \r   @@@@@@@@@@         @   @        @@@@@@@@@@      @@@@@@@@@@   \r                      @   @                             @        \r                     @   @                              @        \r                     @   @                              @        \r                   @@@@@@@@@@                           @        \r                                                        @        \r                                                                \r                                                                \r");
	//串口通信初始化显示图，很长的一串字符
	UARTFIFOLevelSet(UART0_BASE,UART_FIFO_TX2_8,UART_FIFO_RX7_8);
}
void S800_GPIO_Init(void)
{
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);						//Enable PortF
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF));			//Wait for the GPIO moduleF ready
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOJ);						//Enable PortJ
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOJ));			//Wait for the GPIO moduleJ ready
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);						//Enable PortN
	while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPION));			//Wait for the GPIO moduleN ready

  GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_0);			//Set PF0 as Output pin
  GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0);			//Set PN0 as Output pin
  GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_1);		//Set PN1 as Output pin

	GPIOPinTypeGPIOInput(GPIO_PORTJ_BASE,GPIO_PIN_0 | GPIO_PIN_1);//Set the PJ0,PJ1 as input pin
	GPIOPadConfigSet(GPIO_PORTJ_BASE,GPIO_PIN_0 | GPIO_PIN_1,GPIO_STRENGTH_2MA,GPIO_PIN_TYPE_STD_WPU);
}

void S800_I2C0_Init(void)
{
	uint8_t result;
  SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
	GPIOPinConfigure(GPIO_PB2_I2C0SCL);
  GPIOPinConfigure(GPIO_PB3_I2C0SDA);
  GPIOPinTypeI2CSCL(GPIO_PORTB_BASE, GPIO_PIN_2);
  GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_3);

	I2CMasterInitExpClk(I2C0_BASE,ui32SysClock, true);										//config I2C0 400k
	I2CMasterEnable(I2C0_BASE);

	result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_CONFIG_PORT0,0x0ff);		//config port 0 as input
	result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_CONFIG_PORT1,0x0);			//config port 1 as output
	result = I2C0_WriteByte(TCA6424_I2CADDR,TCA6424_CONFIG_PORT2,0x0);			//config port 2 as output

	result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_CONFIG,0x00);					//config port as output
	result = I2C0_WriteByte(PCA9557_I2CADDR,PCA9557_OUTPUT,0x0ff);				//turn off the LED1-8

}


uint8_t I2C0_WriteByte(uint8_t DevAddr, uint8_t RegAddr, uint8_t WriteData)
{
	uint8_t rop;
	while(I2CMasterBusy(I2C0_BASE)){};
	I2CMasterSlaveAddrSet(I2C0_BASE, DevAddr, false);
	I2CMasterDataPut(I2C0_BASE, RegAddr);
	I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_START);
	while(I2CMasterBusy(I2C0_BASE)){};
	rop = (uint8_t)I2CMasterErr(I2C0_BASE);

	I2CMasterDataPut(I2C0_BASE, WriteData);
	I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_FINISH);
	while(I2CMasterBusy(I2C0_BASE)){};

	rop = (uint8_t)I2CMasterErr(I2C0_BASE);
	return rop;
}

uint8_t I2C0_ReadByte(uint8_t DevAddr, uint8_t RegAddr)
{
	uint8_t value,rop;
	while(I2CMasterBusy(I2C0_BASE)){};
	I2CMasterSlaveAddrSet(I2C0_BASE, DevAddr, false);
	I2CMasterDataPut(I2C0_BASE, RegAddr);
//	I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_START);
	I2CMasterControl(I2C0_BASE,I2C_MASTER_CMD_SINGLE_SEND);
	while(I2CMasterBusBusy(I2C0_BASE));
	rop = (uint8_t)I2CMasterErr(I2C0_BASE);
	Delay(1);
	//receive data
	I2CMasterSlaveAddrSet(I2C0_BASE, DevAddr, true);
	I2CMasterControl(I2C0_BASE,I2C_MASTER_CMD_SINGLE_RECEIVE);
	while(I2CMasterBusBusy(I2C0_BASE));
	value=I2CMasterDataGet(I2C0_BASE);
		Delay(1);
	return value;
}
void SysTick_Handler(void)
{
	 if (systick_1000ms_couter == 0)
	{
		systick_1000ms_couter = 1000;
		systick_1000ms_status = 1;
		second++;
	}
	else
		systick_1000ms_couter--;

	if (systick_250ms_couter == 0)
	{
		systick_250ms_couter = 250;
		systick_250ms_status = 1;
	}
	else
		systick_250ms_couter--;

   if(timer_able)
	{ if (systick_10ms_couter == 0)
	{
		systick_10ms_couter = 10;
		systick_10ms_status = 1;
		timer_ms--;
	}
	else
		systick_10ms_couter--;}

if (systick_1ms_couter == 0)
	{
		systick_1ms_couter = 1;
		systick_1ms_status = 1;
		mms++;
	}
	else
		systick_1ms_couter--;
}

int strcasecmp_custom(const char *s1, const char *s2) {//使得输入不记大小写
    while (*s1 && *s2) {
        int diff = tolower(*s1) - tolower(*s2);
        if (diff != 0)
            return diff;
        s1++;
        s2++;
    }
    return tolower(*s1) - tolower(*s2);
}

int strncasecmp_custom(const char *s1, const char *s2, int n) {//使得输入不记大小写
    for(i=0;i<n;++i) {
        int diff = tolower(*s1) - tolower(*s2);
        if (diff != 0)
            return diff;
        s1++;
        s2++;
    }
    return 0;
}


void remove_spaces(char *str) {//消除输入的空格
    char *src = str;
    char *dst = str;
    while (*src) {
        if (!isspace((unsigned char)*src)) {
            *dst++ = *src;
        }
        src++;
    }
    *dst = '\0';
}

void UART0_Handler(void) {
    int32_t uart0_int_status;
    int hour1, minute1, second1;

    uart0_int_status = UARTIntStatus(UART0_BASE, true);    // Get the interrupt status.

    UARTIntClear(UART0_BASE, uart0_int_status);    // Clear the asserted interrupts

    UARTStringGetNonBlocking();

    remove_spaces(RxBuf);    // Remove spaces from the input string

    
    
	  if(strcasecmp_custom(RxBuf, "?") == 0)
		{
			UARTStringPutNonBlocking("\n1.INITCLOCK \n2.INITSERIAL\n3. SETTIME:Txx:xx:xx\n4. SETDATE:Dxxxx/xx/xx\n5. CLOCK:Axx:xx:xx \n6. TIMER:Cxx.xx \n7. GET TIME\n8. GET DATE\n9. GET ALARM\n10. GET TIMER\n11. RUNTIME\n12. RUNDATE\n13. RUNALARM\n14. RUNSWATCH\n15. RESET");
		}
	  // 重启
	  else if(strcasecmp_custom(RxBuf, "RESET") == 0)
    {
			UARTStringPutNonBlocking("Reset!\n");
			SysCtlReset();
    }
    //设置时间
    else if (strncasecmp_custom(RxBuf, "T", 1) == 0) {
			if (RxBuf[3] == ':' && RxBuf[6] == ':') {
        hour1 = (RxBuf[1] - '0') * 10 + (RxBuf[2] - '0');
        minute1 = (RxBuf[4] - '0') * 10 + (RxBuf[5] - '0');
        second1 = (RxBuf[7] - '0') * 10 + (RxBuf[8] - '0');

        if (hour1 >= 24 || minute1 >= 60 || second1 >= 60)
            UARTStringPutNonBlocking("Invalid Inputs!!!");
        else {
            hour = hour1;
            minute = minute1;
            second = second1;

            sprintf(look, "%4s%02u%s%02u%s%02u", "SETTIME", hour, ":", minute, ":", second);
            UARTStringPutNonBlocking(look);
            counter=1;
        }
    }
    else
        UARTStringPutNonBlocking("Invalid Inputs!!!");
}
    //设置闹钟
    else if (strncasecmp_custom(RxBuf, "A", 1) == 0) {
			if (RxBuf[3] == ':' && RxBuf[6] == ':') {
        hour1 = (RxBuf[1] - '0') * 10 + (RxBuf[2] - '0');
        minute1 = (RxBuf[4] - '0') * 10 + (RxBuf[5] - '0');
        second1 = (RxBuf[7] - '0') * 10 + (RxBuf[8] - '0');

        if (hour1 >= 24 || minute1 >= 60 || second1 >= 60)
            UARTStringPutNonBlocking("Invalid Inputs!!!");
        else {
            clock_hour = hour1;
            clock_minute = minute1;
            clock_second = second1;

            sprintf(look, "%4s%02u%s%02u%s%02u", "SETALARM", clock_hour, ":", clock_minute, ":", clock_second);
            UARTStringPutNonBlocking(look);
					  counter=5;
        }
    }
    else
        UARTStringPutNonBlocking("Invalid Inputs!!!");
}
    //设置日期
    else if (strncasecmp_custom(RxBuf, "D", 1) == 0) {
			if (RxBuf[5] == '/' && RxBuf[8] == '/') {
        hour1 = (RxBuf[1] - '0') * 1000 + (RxBuf[2] - '0')*100+(RxBuf[3]-'0')*10+(RxBuf[4]-'0');
        minute1 = (RxBuf[6] - '0') * 10 + (RxBuf[7] - '0');
        second1 = (RxBuf[9] - '0') * 10 + (RxBuf[10] - '0');

        if (minute1 >= 13 || second1 >= 32)
            UARTStringPutNonBlocking("Invalid Inputs!!!");
        else {
            year = hour1;
            month = minute1;
            day = second1;

            sprintf(look, "%4s%02u%s%02u%s%02u", "SETDATE", year, "/", month, "/", day);
            UARTStringPutNonBlocking(look);
					  counter=3;
        }
    }
    else
        UARTStringPutNonBlocking("Invalid Inputs!!!");
}
    //设置倒计时
    else if (strncasecmp_custom(RxBuf, "C", 1) == 0) {
			if (RxBuf[3] == '.' ) {
        hour1 = (RxBuf[1] - '0') * 10 + (RxBuf[2] - '0');
        minute1 = (RxBuf[4] - '0') * 10 + (RxBuf[5] - '0');

        if (timer_s >= 100 || timer_ms >= 100)
            UARTStringPutNonBlocking("Invalid Inputs!!!");
        else {
            timer_s = hour1;
            timer_ms = minute1;

            sprintf(look, "%s%d.%02d", "SETTIMER", timer_s, timer_ms);
            UARTStringPutNonBlocking(look);
					  counter=6;
        }
    }
    else
        UARTStringPutNonBlocking("Invalid Inputs!!!");
}
    //初始化时钟
    else if (strcasecmp_custom(RxBuf, "INITCLOCK") == 0) {
        ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_16MHZ |SYSCTL_OSC_INT | SYSCTL_USE_PLL |SYSCTL_CFG_VCO_480), 20000000);
        UARTStringPutNonBlocking("Clock initialized!\n");
    }

    //初始化串口通信
    else if (strcasecmp_custom(RxBuf, "INITSERIAL") == 0) {
        S800_UART_Init();
        UARTStringPutNonBlocking("Serial port initialized!\n");
    }

    // "GETTIME"
    else if (strcasecmp_custom(RxBuf, "GETTIME") == 0) {
        sprintf(look, "%4s%02u%s%02u%s%02u", "TIME", hour, ":", minute, ":", second);
        UARTStringPutNonBlocking(look);
    }

    // "GETDATE"
    else if (strcasecmp_custom(RxBuf, "GETDATE") == 0) {
        sprintf(look, "%4s%02u%s%02u%s%02u", "DATE", year, "/", month, "/", day);
        UARTStringPutNonBlocking(look);
    }

    // "GETALARM"
    else if (strcasecmp_custom(RxBuf, "GETALARM") == 0) {
        sprintf(look, "%4s%02u%s%02u%s%02u", "ALARM", clock_hour, ":", clock_minute, ":", clock_second);
        UARTStringPutNonBlocking(look);
    }
    // "GETTIMER"
    else if (strcasecmp_custom(RxBuf, "GETTIMER") == 0) {
    sprintf(look, "%s%d.%02d", "TIMER", timer_s, timer_ms);
        UARTStringPutNonBlocking(look);
    }
    //显示时间
    else if (strcasecmp_custom(RxBuf, "RUNTIME") == 0) {
        counter=1;
        sprintf(look, "%4s%02u%s%02u%s%02u", "TIME", hour, ":", minute, ":", second);
        UARTStringPutNonBlocking(look);
    }
    //显示日期
    else if (strcasecmp_custom(RxBuf, "RUNDATE") == 0) {
        counter=3;
        sprintf(look, "%4s%02u%s%02u%s%02u", "DATE", year, "/", month, "/", day);
        UARTStringPutNonBlocking(look);
    }
    //显示闹钟并使能
    else if (strcasecmp_custom(RxBuf, "RUNALARM") == 0) {
        counter=5;
			  clock_able=!clock_able;
        sprintf(look, "%4s%02u%s%02u%s%02u", "ALARM", clock_hour, ":", clock_minute, ":", clock_second);
        UARTStringPutNonBlocking(look);
    }
    //显示倒计时并开始计时
    else if (strcasecmp_custom(RxBuf, "RUNSWATCH") == 0) {
    counter = 6;
    timer_able = !timer_able;
    sprintf(look, "%s%d.%02d", "TIMER", timer_s, timer_ms);
        UARTStringPutNonBlocking(look);

}

    //无匹配指令，错误
    else UARTStringPut((uint8_t *)"\r\nerror!\r\n");

    memset(RxBuf, 0, sizeof(RxBuf));
}
